# AllJoyn samples

These samples demonstrate how to create an AllJoyn Windows Universal app using Code Generation with Introspection XML and Windows.Devices.AllJoyn.

* [AllJoyn Producer Experiences](http://go.microsoft.com/fwlink/p/?LinkId=534025)
* [AllJoyn Consumer Experiences](http://go.microsoft.com/fwlink/p/?LinkID=534021)
